Run jb_5956355: actual generation-10 checkpoint population, in checkpoint order.
28 distinct survivor IDs, selected from the checkpoint population, not ranked by score.
The full candidate log contains 238 candidate IDs and 7,140 candidate-behavior rows.
Filtering it by these IDs gives 840 rows: 28 candidates x 30 behaviors.
Includes survivors evaluated in earlier generations.
Three survivors have non-finite checkpoint fitness; they are retained here exactly as saved.
The original checkpoint includes population and hall of fame; use population for this cohort.
The pickle requires Python with DEAP to load.
Historical verification results predate the independent verification-temperature fix.
