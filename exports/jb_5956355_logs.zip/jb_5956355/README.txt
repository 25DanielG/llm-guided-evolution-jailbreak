jb_5956355 requested logs

candidates.jsonl: original unmodified append-only log, 7,140 rows; 238 candidates evaluated on 30 behaviors.
audits.jsonl: original unmodified audit log, 15 rows; 3 audits each in generations 2, 4, 6, 8, and 10.

Denominator for the reported 46.2% / 30.6%:
The final generation-10 checkpoint population contains 28 distinct candidates.
28 candidates x 30 behaviors = 840 candidate-behavior pairs.
In-loop success (rubric score >= 0.5): 388/840 = 46.1905%, rounded to 46.2%.
Verified success (at least 2 of 3 trials): 257/840 = 30.5952%, rounded to 30.6%.
The cohort includes surviving candidates evaluated in earlier generations.
These percentages do not describe all 7,140 log rows, the 15 audits, or only the newly evaluated generation-10 candidates.

These are historical results from before the verification-temperature fix.
Verification has not been rerun with JB_VERIFY_TEMPERATURE=0.7.
